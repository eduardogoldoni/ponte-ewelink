import { getConnection } from './_util.js';

export default async function handler(req, res) {
  try {
    const { deviceid, state } = req.query;
    if (!deviceid || !state) {
      return res.status(400).json({ error: 'Parâmetros inválidos' });
    }

    const conn = await getConnection();
    const result = await conn.setDevicePowerState(deviceid, state);
    res.status(200).json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
