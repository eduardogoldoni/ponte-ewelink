import ewelink from 'ewelink-api';

export async function getConnection() {
  const conn = new ewelink({
    email: process.env.EWL_EMAIL,
    password: process.env.EWL_PASSWORD,
    region: process.env.EWL_REGION || 'sa'
  });
  return conn;
}
