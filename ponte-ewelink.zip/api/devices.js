import { getConnection } from './_util.js';

export default async function handler(req, res) {
  try {
    const conn = await getConnection();
    const devices = await conn.getDevices();
    res.status(200).json(devices);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
}
